function Main_DEAUndesirable()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-xdata' '.idea-ydata' '.idea-zdata' for each dataset

% *** Pls select the type of UDEA model
userSetting.UDEAType = 'UDEA_CAD2020'; % 'UDEA_EJOR2002', 'UDEA_JORS2019', 'UDEA_CAD2020'
% ==> 'UDEA_EJOR2002': UDEA_EJOR2002 model
% ==> 'UDEA_JORS2019': UDEA_JORS2019 model
% ==> 'UDEA_CAD2020' : UDEA_CAD2020 model

%% Pls do not modify the codes belows
IDEA_DEAUndesirable(userSetting);
end

