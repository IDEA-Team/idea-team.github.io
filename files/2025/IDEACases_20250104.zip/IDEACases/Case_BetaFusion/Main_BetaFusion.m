function Main_BetaFusion()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'};  
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-betadata' '.idea-wdata' for each dataset

% *** Pls select the type of integrating belief distributions
userSetting.fusionType = 'UsingERRule'; % 'UsingER', 'UsingWA', 'UsingCCRule', 'UsingERRule'
% ==> UsingER    : Evidential Reasoning
% ==> UsingWA    : Weighted Average
% ==> UsingCCRule: Cautious Conjunctive Rule
% ==> UsingERRule: Evidential Reasoning Rule
% ==> If userSetting.fusionType = 'UsingERRule', pls provide '.idea-rdata'

%% Pls do not modify the codes belows
IDEA_BetaFusion(userSetting);
end

