function Main_NoparametricTest()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910
% Ref.[1] : Garcia S., et al. Advanced nonparametric tests for multiple comparisons in the design of experiments in computational intelligence and data mining-Experimental analysis of power. Information Sciences, 2010.

%% Pls define your settings in this section
% *** Pls input your data
userSetting.dataMatrix = [
    89.69	86.34	86.14
    48.60	41.34	41.68
    70.24	65.19	67.08
    57.20	52.79	53.53
    ];
% ==> userSetting.dataMatrix(i,j): value of the ith dataset and the jth method

% *** Pls define which one is the target method
userSetting.targetMethodIdx = 1;

% *** Pls select the type of data
userSetting.dataType = 'Cost'; % 'Cost', 'Benefit'
% ==> Cost   : the smaller, the better
% ==> Benefit: the bigger, the better

% *** Pls define alpha
userSetting.alpha = 0.05;

% *** Pls select the type of multiple comparison test
userSetting.multCmpTest = 'Friedman'; % 'Friedman', 'FriedmanAlignedRanks', 'Quade'
% ==> See Ref.[1] for details

% *** Pls select the type of post-hoc procedures for comparing a control method
userSetting.postHocTest = 'BonferroniDunn'; % 'None', 'BonferroniDunn', 'Holm', 'Holland', 'Finner', 'Hochberg'
% ==> None: do not run postHocTest
% ==> See Ref.[1] for details

%% Pls do not modify the codes belows
IDEA_NoparametricTest(userSetting);
end

