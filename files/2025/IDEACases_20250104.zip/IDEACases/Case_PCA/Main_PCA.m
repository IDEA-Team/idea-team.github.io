function Main_PCA()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'};
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls determine if use testing data together with training data to run PCA
userSetting.includeTstData = true; % true, false

% *** Pls define the type of selecting key indicators
userSetting.keyIndicatorSelectionType = 'LoadingMatrix' ; % 'LoadingMatrix', 'PCSpace'
% ==> PCSpace      : To select key indicators from principal component space
% ==> LoadingMatrix: To select key indicators from original space using loading matrix

% *** Pls define the type of determining the number key indicators
userSetting.keyIndicatorNumberType = 'MinACR'; % 'IndicatorNumber' 'MinEigenvalue' 'MinACR' 
% ==> If userSetting.keyIndicatorSelectionType = 'IndicatorNumber', pls determine userSetting.keyIndicatorNumber
% ====> Pls determine the number of key indicators
userSetting.keyIndicatorNumber = 3; % Integer with value range [1, +Inf]
% ==> If userSetting.keyIndicatorSelectionType = 'MinEigenvalue', pls determine userSetting.minEigenvalue
% ====> Pls determine the minimum value of key eigenvalue
userSetting.minEigenvalue = 1.0; % float with value range [0, +Inf]
% ==> If userSetting.keyIndicatorSelectionType = 'MinACR', pls determine userSetting.minACR
% ====> Pls determine the minimum value of accumulative contribution ratio (ACR)
userSetting.minACR = 0.9; % float with value range [0, 1]

%% Pls do not modify the codes belows
IDEA_PCA(userSetting);
end

