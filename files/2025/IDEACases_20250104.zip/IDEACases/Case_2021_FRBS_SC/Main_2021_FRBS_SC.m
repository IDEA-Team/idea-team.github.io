function Main_2021_FRBS_SC()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Yang LH, et al, An improved fuzzy rule-based system using evidential reasoning and subtractive clustering for environmental investment prediction. Fuzzy Sets and Systems, 2021, 421: 44-61.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls define the value of delta for subtractive clustering  
userSetting.delta = 0.0; % float, value range [0, 1], Eq.(16) at Ref.[1]

% *** Pls define the value of factor to calculate the neighborhod radius  
userSetting.rAFactor = 0.1; % float, value range [0, 1], Eq.(14) at Ref.[1], e.g., 0.5 at Eq.(14)

% *** Pls define the number of fuzzy labels for antecedent and consequent attributes  
userSetting.fuzzyLabelNum = 3; % integer, value range [2, inf]

%% Pls do not modify the codes belows
IDEA_2021_FRBS_SC(userSetting);
end

