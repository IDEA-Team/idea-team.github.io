function Main_2018_JOPS_BRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Yang L.H., Wang Y.M., Liu J., Mart��nez L., A joint optimization method on parameter and structure for belief-rule-based systems[J]. Knowledge-Based Systems, 2018, 142: 220-240.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

userSetting.S2Value  = 3;   % integer, value range [1, inf], JOPS algorithm at P229 of Ref.[1]
userSetting.rValue   = 0.1; % float, value range (0, 1], Eq.(16) of Ref.[1]
userSetting.rouValue = 0.7; % float, value range (0, 1], SOHS algorithm at P228 of Ref.[1]
% *** Pls select a way to give basic parameters,  
userSetting.maxAnteAttrUtilNum = 6; % integer, value range [2, inf], maximum number of grades for each antecedent attribute
userSetting.conqAttrUtilNum    = 5; % integer, value range [2, inf]

% *** Pls select a way to achieve parameter learning. 
userSetting.paraLearningType = 'UsingDE'; % 'UsingNone', 'UsingDE', 'UsingGA', 'UsingPS', 'UsingFmincon'
% ==> UsingNone   : do not use parameter learning. 
% ==> UsingDE     : Differential Evoluation Algorithm. 
% ==> UsingGA     : Genetic Algorithm. 
% ==> UsingPS     : Pattern Search Algorithm. 
% ==> UsingFmincon: Fmincon in MATLAB
% ==> when UserSetting.paraLearningType ~= 'UsingNone', pls give UserSetting.parNum and UserSetting.genNum % Eq.(29) at Ref.[1]
userSetting.parNum = 50; % integer, value range [1, inf]
userSetting.genNum = 10; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_2018_JOPS_BRB(userSetting);
end

