function Main_2023_MTS_BRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] :	Yang LH, et al, Belief rule-base expert system with multilayer tree structure for complex problems modeling[J]. Expert Systems with Applications, 2023, 217: 119567.
%% Pls define your settings in this section
% Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'};  
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-betadata' '.idea-wdata' for each dataset

% Pls give the number of assessment grades for antecedent attributes, 
userSetting.anteAttrUtilNum  = 5; % integer, value range [2, 10]

% Pls define the number of sub-groups for each attribute group
userSetting.attrGroupNum = 3; % integer, value range [2, 5]

% Pls define the number of attributes in each attribute group
userSetting.attrNumInGroup = 3; % integer, value range [2, 5]

% *** Pls select a way to achieve parameter learning. 
userSetting.runParaLearning = true; % true, false
% ==> when UserSetting.runParaLearning = true, pls give UserSetting.parNum and UserSetting.genNum
userSetting.parNum = 50;  % integer, value range [1, 100]
userSetting.genNum = 200; % integer, value range [1, inf]


%% Pls do not modify the codes belows
IDEA_2023_MTS_BRB(userSetting);
end

