function Main_2006_BRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Yang J.B., et al., Belief rule-base inference methodology using the evidential reasoning approach - RIMER[J]. IEEE Transactions on Systems, Man, and Cybernetics - Part A: Systems and Humans, 2006, 36(2): 266-285.
% Ref.[2] : Wang Y.M., et al., Dynamic rule adjustment approach for optimizing belief rule-base expert system[J]. Knowledge-Based Systems, 2016, 96: 40-60.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls select a way to give basic parameters,  
userSetting.baseParaType = 'UsingAvgBasePara'; % 'UsingIniBasePara', 'UsingOptBasePara', 'UsingAvgBasePara'
% ==> UsingAvgBasePara: the parameters are automaticaly assigned by average values; 
% ==> UsingIniBasePara: using '.idea-inipara' file and Pls provide '.idea-inipara'
% ==> UsingOptBasePara: using '.idea-optpara' file and Pls provide '.idea-optpara'
% ==> when UserSetting.baseParaType = 'UsingAvgBasePara', pls give UserSetting.anteUtilNum and UserSetting.conqUtilNum
userSetting.anteAttrUtilNum = 3; % integer, value range [2, inf]
userSetting.conqAttrUtilNum = 5; % integer, value range [2, inf]

% *** Pls select a way to achieve parameter learning, pls see Ref.[2]
userSetting.paraLearningType = 'UsingDE'; % 'UsingNone', 'UsingDE', 'UsingGA', 'UsingPS', 'UsingFmincon'
% ==> UsingNone    : do not use parameter learning. 
% ==> UsingDE      : Differential Evoluation Algorithm. 
% ==> UsingGA      : Genetic Algorithm. 
% ==> UsingPS      : Pattern Search Algorithm. 
% ==> UsingFmincon : Fmincon in MATLAB
% ==> when UserSetting.paraLearningType ~= 'UsingNone', pls give UserSetting.parNum and UserSetting.genNum
userSetting.parNum = 50; % integer, value range [1, inf]
userSetting.genNum = 10; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_2006_BRB(userSetting);
end

