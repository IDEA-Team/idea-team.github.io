function Main_2023_AP_EBRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Fu C, et al, Extended Belief Rule-Based System with Accurate Rule Weights and Efficient Rule Activation for Diagnosis of Thyroid Nodules[J]. IEEE Transactions on Systems, Man, and Cybernetics: Systems, 2023, 53(1): 251-263.
%% Pls define your settings in this section
% Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'};  
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-betadata' '.idea-wdata' for each dataset

% Pls give the number of assessment grades for antecedent attributes, 
userSetting.anteAttrUtilNum  = 5; % integer, value range [2, inf]

% Pls define the parameters related to AP algorithm
userSetting.threOfClu_L = 2;
userSetting.threOfClu_U = 10;

%% Pls do not modify the codes belows
IDEA_2023_AP_EBRB(userSetting);
end

