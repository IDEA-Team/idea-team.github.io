function Main_ZSGDEA()
% Homepage : https://idea-team.github.io
% Author   : Dr. Long-Hao Yang
% E-mail   : more026@hotmail.com
% Date     : 2025.01.04

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-3', 'case-2'};
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-xdata' '.idea-ydata' for each dataset

%% Pls do not modify the codes belows
IDEA_ZSGDEA(userSetting);
end

