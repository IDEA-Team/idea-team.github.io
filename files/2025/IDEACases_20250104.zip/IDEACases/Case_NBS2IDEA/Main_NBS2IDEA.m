function Main_NBS2IDEA()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetName = 'case-1_2004-2021';
% ==> e.g. 'case-1_2004-2021'
% ==> Pls provide '.xlsx' for the dataset

% *** Pls give the name of provinces
userSetting.provinceNames = {
    'Beijing' , 'Tianjin'  , 'Hebei'       , 'Shanxi'   , 'InnerMongolia' , ...
    'Liaoning', 'Jilin'    , 'Heilongjiang', 'Shanghai' , 'Jiangsu'       , ...
    'Zhejiang', 'Anhui'    , 'Fujian'      , 'Jiangxi'  , 'Shandong'      , ...
    'Henan'   , 'Hubei'    , 'Hunan'       , 'Guangdong', 'Guangxi'       , ...
    'Hainan'  , 'Chongqing', 'Sichuan'     , 'Guizhou'  , 'Yunnan'        , ...
    'Shaanxi' , 'Gansu'    , 'Qinghai'     , 'Ningxia'  , 'Xinjiang'
    };
% ==> Pls be consist with the name in '.xlsx' file
% ==> Pls use English name, not use Chinese

% *** Pls give the name of years
userSetting.yearNames = {
    '2021', '2020', '2019', '2018', '2017', ...
    '2016', '2015', '2014', '2013', '2012', ...
    '2011', '2010', '2009', '2008', '2007', ...
    '2006', '2005', '2004'
    };
% ==> Pls be consist with the name in '.xlsx' file
% ==> Pls use English name, not use Chinese

% *** Pls give the name of the years as testing data
userSetting.tstYearNames = {
    '2021', '2020', '2019'
    };
% ==> Pls be consist with the name in '.xlsx' file
% ==> Pls use English name, not use Chinese

% *** Pls give the name of antecedent attributes
userSetting.antecedentAttributeNames = {
    'GDP', 'SO2'
    };
% ==> Pls be consist with the name of sheet at '.xlsx' file
% ==> Pls use English name, not use Chinese

% *** Pls give the name of one consequent attribute
userSetting.consequentAttributeName = 'InvestmentToWasteGas';
% ==> Pls be consist with the name of sheet at '.xlsx' file
% ==> Pls use English name, not use Chinese

% *** Pls give the table range in '.xlsx' file
userSetting.xlsxTableRange = 'A4:S34';
% ==> A4: the cell of the 4the row and the Ath column 
% ==> Pls make the range including the title of provinces and years

%% Pls do not modify the codes belows
IDEA_NBS2IDEA(userSetting);
end

