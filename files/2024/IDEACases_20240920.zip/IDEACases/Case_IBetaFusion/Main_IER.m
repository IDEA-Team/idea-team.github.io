function Main_IER()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910
% Ref.[1] :Y.M. Wang, et al. The evidential reasoning approach for multiple attribute decision analysis using interval belief degrees. European Journal of Operational Research, 2006.

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-lowerbetadata' '.idea-lowerbetadata' '.idea-wdata' for each dataset

% *** Pls select the type of target function
userSetting.targetFunctionType = 'UsingBeta'; % 'UsingBeta', 'UsingUtility'
% ==> UsingBeta   : Eq. (54) at Ref.[1] 
% ==> UsingUtility: Eqs. (66) and (76) at Ref. [1]
% ==> If userSetting.targetFunctionType = 'UsingUtility', please provide '.idea-udata'.

% *** Pls select the type of determining uncertain beta
userSetting.intervalBetaHType = 'UsingCalculation'; % 'UsingCalculation', 'UsingExpert', 'UsingZero'
% ==> 'UsingCalculation': Using Eq. (21) to calculate the lower and upper beta_H. 
% ==> 'UsingExpert'     : Reading '.idea-lowerbetahdata' and '.idea-upperbetahdata' to define the lower and upper betaH. 
% ==> 'UsingZero'       : the lower and upper betaH are 0.
% ==> If userSetting.intervalBetaHType = 'UsingExpert', please provide '.idea-lowerbetahdata' and '.idea-upperbetahdata'.

%% Pls do not modify the codes belows
IDEA_IER(userSetting);
end

