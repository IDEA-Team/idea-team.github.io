function Main_2023_RGM()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Liu L.Y., et al., The recursive grey model and its application. Applied Mathematical Modelling, 2023.
%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Please determine the number of future times to predict 
userSetting.nxtTimeNum = 3; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_2023_RGM(userSetting);
end

