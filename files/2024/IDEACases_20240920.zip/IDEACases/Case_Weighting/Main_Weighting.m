function Main_Weighting()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the address of dataset
userSetting.dataSetAddr  = 'IDEACases_20240910\Case_CBRB';
% ==> e.g. 'IDEACases_20240910\Case_CBRB'

% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'};
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' and '.idea-attrtype' for each dataset

% *** Pls give the type of calculating weights
userSetting.calWeightType = 'Pearson'; % 'CCSD', 'Entropy', 'Relieff', 'Pearson'
% ==> CCSD   : Correlation Coefficient and Standard Deviation
% ==> Entropy: Entropy weighting
% ==> Relieff: Relieff weighting
% ==> Pearson: Pearson correlation weighting
% =================================================================
% ==> If userSetting.calWeightType = 'Relieff', pls determine userSetting.kValue
% ====> Pls determine the number of nearest neighbours to perform relieff algorithm
userSetting.kValue = 2; % Integer, [1, +Inf]

% *** Pls determine if use testing data together with training data to calculate weights
userSetting.includeTstData = true; % true, false

% *** Pls determine if select key indicators based on weights
userSetting.selectKeyIndicators = true; % true, false
% ==> If userSetting.selectKeyIndicators = true, pls determine userSetting.keyIndicatorNumber
% ====> Pls determine the number of key indicators selected by using the weights
userSetting.keyIndicatorNumber  = 3;

%% Pls do not modify the codes belows
IDEA_Weighting(userSetting);
end

