function Main_2022_FW_SMOTE()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Maldonado et al., FW-SMOTE: A feature-weighted oversampling approach for imbalanced classification. Pattern Recognition, 2022, 124: 108511.
%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls give an integer to determine the number of nearest neigbuors  
userSetting.kValue = 5; % integer, value range [1, inf]

% *** Pls select a way to give distance type,  
userSetting.distanceType  = 'euclidean';
% ==> 'euclidean'       : Euclidean distance 
% ==> 'squaredeuclidean': Squared Euclidean distance
% ==> 'seuclidean'      : Standardized Euclidean distance
% ==> 'mahalanobis'     : Mahalanobis distance
% ==> 'minkowski'       : Minkowski distance
% pls see pdist function for details,

% *** Pls select a way to give filtering type,  
userSetting.filteringType = 'FisherScore'; 
% ==> 'FisherScore'          : Eq.(6) at Ref.[1]
% ==> 'MutualInformation'    : Eq.(7) at Ref.[1]
% ==> 'CorrelationScore'     : Eq.(8) at Ref.[1]
% ==> 'EigenvectorCentrality': P5 at Ref.[1]

% *** Pls give an integer to determine the number of key attributes  
userSetting.keyAttrNum = 3; % integer, value range [1, inf]

% *** Pls give a float value to determine the number of key attributes  
userSetting.alphaOWA = 0.5; % float, value range (0, 1)

% *** Pls select a way to give OWA type, 
userSetting.OWAType = 'BasicRIM';
% ==> 'BasicRIM'        : Eq.(9) at Ref.[1]
% ==> 'QuadraticRIM'    : Eq.(10) at Ref.[1]
% ==> 'ExponentialRIM'  : Eq.(11) at Ref.[1]
% ==> 'TrigonometricRIM': Eq.(12) at Ref.[1]

%% Pls do not modify the codes belows
IDEA_2022_FW_SMOTE(userSetting);
end

