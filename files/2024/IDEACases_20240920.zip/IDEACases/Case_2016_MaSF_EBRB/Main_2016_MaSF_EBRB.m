function Main_2016_MaSF_EBRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] :	Yang LH, et al., Multi-attribute search framework for optimizing extended belief rule-based systems[J]. Information Sciences, 2016, 370-371: 159-183.
% Ref.[2] : Yang LH, et al., Highly explainable cumulative belief rule-based system with effective rule-base modeling and inference scheme[J]. Knowledge-Based Systems, 2022, 240: 107805.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls give the value of p
userSetting.pValue = 0.1; % float, value range (0, 1], SBR algorithm of P172 at Ref.[1]

% *** Pls select a way to calculate rule weights, 
userSetting.ruleWCalculationType = 'UsingBigDataWeight'; % 'UsingMeasureWeight', 'UsingBigDataWeight'
% ==> UsingBigDataWeight: all rule weights = 1.0; Eqs.(A.1) to (A.2) at Ref.[2]
% ==> UsingMeasureWeight: using similarity measure to calculate rule weights; Eqs.(5) to (6) at Ref.[2]

% *** Pls select a way to measure the similarity between belief distributions, 
userSetting.BDSimilarityType = 'UsingStandardizedEuclidean'; % 'UsingActiFactorEuclidean', 'UsingStandardizedEuclidean'
% ==> UsingStandardizedEuclidean: the standardized Euclidean distance; % Eq.(21) at Ref.[2]
% ==> UsingActiFactorEuclidean  : the activation factor-based Euclidean distance. % Eq.(22) at Ref.[2]
% ==> when UserSetting.BDSimilarityType = 'UsingActiFactorEuclidean', pls give UserSetting.actiFactor
userSetting.actiFactor = 1.0; % float, value range (0, 2]

% *** Pls select a way to give basic parameters,  
userSetting.baseParaType = 'UsingAvgBasePara'; % 'UsingIniBasePara', 'UsingOptBasePara', 'UsingAvgBasePara'
% ==> UsingAvgBasePara: the parameters are automaticaly assigned by average values; 
% ==> UsingIniBasePara: using '.idea-inipara' file and Pls provide '.idea-inipara'
% ==> UsingOptBasePara: using '.idea-optpara' file and Pls provide '.idea-optpara'
% ==> when UserSetting.baseParaType = 'UsingAvgBasePara', pls give UserSetting.anteUtilNum and UserSetting.conqUtilNum
userSetting.anteAttrUtilNum = 5; % integer, value range [2, inf]
userSetting.conqAttrUtilNum = 5; % integer, value range [2, inf]


%% Pls do not modify the codes belows
IDEA_2016_MaSF_EBRB(userSetting);
end

