function Main_2020_DCFS()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : 2024.09.16
% Ref.[1] : Wang LX, Fast Training Algorithms for Deep Convolutional Fuzzy Systems with Application to Stock Index Prediction[J]. IEEE Transactions on Fuzzy Systems, 2020, 28(7): 1301-1314.

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Please give the number of fuzzy labels for attributes 
userSetting.fuzzyLabelNum = 5; % integer, value range [2, inf]

% *** Please give the number of attributes in a window, 
userSetting.winAttrNum = 3; % integer, value range [2, inf]

%% Pls do not modify the codes belows
IDEA_2020_DCFS(userSetting);
end

