function Main_2021_MicroEBRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] :	Yang LH, et al., A Micro-Extended Belief Rule-Based System for Big Data Multiclass Classification Problems[J]. IEEE Transactions on Systems, Man, and Cybernetics: Systems, 2021, 51(1): 420-440.
% Ref.[2] : Yang LH, et al., Highly explainable cumulative belief rule-based system with effective rule-base modeling and inference scheme[J]. Knowledge-Based Systems, 2022, 240: 107805.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls select a way to calculate rule weights, 
userSetting.ruleWCalculationType = 'UsingBigDataWeight'; % 'UsingMeasureWeight', 'UsingBigDataWeight'
% ==> UsingBigDataWeight: all rule weights = 1.0; Eqs.(A.1) to (A.2) at Ref.[2]
% ==> UsingMeasureWeight: using similarity measure to calculate rule weights; Eqs.(5) to (6) at Ref.[2]

% *** Pls select a way to generate belief distributions, 
userSetting.BDGenerationType = 'UsingAdjacentUFunction'; % 'UsingAdjacentUFunction', 'UsingMinimaxUFunction'
% ==> UsingAdjacentUFunction: the adjacent utility-based information transformation; Eq.(8) at Ref.[2]
% ==> UsingMinimaxUFunction : the min/max utility-based information % transformation; Eq.(9) at Ref.[2]

% *** Pls select a way to measure the similarity between belief distributions, 
userSetting.BDSimilarityType = 'UsingActiFactorEuclidean'; % 'UsingActiFactorEuclidean', 'UsingStandardizedEuclidean'
% ==> UsingStandardizedEuclidean: the standardized Euclidean distance; % Eq.(21) at Ref.[2]
% ==> UsingActiFactorEuclidean  : the activation factor-based Euclidean distance. % Eq.(22) at Ref.[2]
% ==> when UserSetting.BDSimilarityType = 'UsingActiFactorEuclidean', pls give UserSetting.actiFactor
userSetting.actiFactor = 1.0; % float, value range (0, 2]

% *** Pls select a way to give basic parameters,  
userSetting.baseParaType = 'UsingAvgBasePara'; % 'UsingIniBasePara', 'UsingOptBasePara', 'UsingAvgBasePara'
% ==> UsingAvgBasePara: the parameters are automaticaly assigned by average values; 
% ==> UsingIniBasePara: using '.idea-inipara' file and Pls provide '.idea-inipara'
% ==> UsingOptBasePara: using '.idea-optpara' file and Pls provide '.idea-optpara'
% ==> when UserSetting.baseParaType = 'UsingAvgBasePara', pls give UserSetting.anteUtilNum and UserSetting.conqUtilNum
userSetting.anteAttrUtilNum = 5; % integer, value range [2, inf]
userSetting.conqAttrUtilNum = 5; % integer, value range [2, inf]

% *** Pls select a way to achieve parameter learning. 
userSetting.paraLearningType = 'UsingDE'; % 'UsingNone', 'UsingDE', 'UsingGA', 'UsingPS', 'UsingFmincon'
% ==> UsingNone   : do not use parameter learning. 
% ==> UsingDE     : Differential Evoluation Algorithm. 
% ==> UsingGA     : Genetic Algorithm. 
% ==> UsingPS     : Pattern Search Algorithm. 
% ==> UsingFmincon: Fmincon in MATLAB
% ==> when UserSetting.paraLearningType ~= 'UsingNone', pls give UserSetting.parNum and UserSetting.genNum % Eq.(29) at Ref.[2]
userSetting.parNum = 50;  % integer, value range [1, inf]
userSetting.genNum = 30; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_2021_MicroEBRB(userSetting);
end

