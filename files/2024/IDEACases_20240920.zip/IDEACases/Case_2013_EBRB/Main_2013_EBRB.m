function Main_2013_EBRB()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Date    : 2024.09.16
% Ref.[1] : Liu J., et al., A novel belief rule base representation, generation and its inference methodology[J]. Knowledge-Based Systems, 2013, 53: 129-141.
% Ref.[2] : Yang L.H., et al., New activation weight calculation and parameter optimization for extended belief rule-based system based on sensitivity analysis[J]. Knowledge and Information Systems, 2019, 60(2): 837-878.
% Ref.[3] : Yang L.H., et al., Highly explainable cumulative belief rule- based system with effective rule-base modeling and inference scheme[J]. Knowledge-Based Systems, 2022, 240: 107805.

%% Pls define your settings in this section
% *** Pls give the name of datasets
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g. {'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Pls select a way to measure the similarity between belief distributions, 
userSetting.BDSimilarityType = 'UsingStandardizedEuclidean'; % 'UsingActiFactorEuclidean', 'UsingStandardizedEuclidean'
% ==> UsingStandardizedEuclidean: the standardized Euclidean distance; % Eq.(21) at Ref.[3]
% ==> UsingActiFactorEuclidean  : the activation factor-based Euclidean distance. % Eq.(22) at Ref.[3]
% ==> when UserSetting.BDSimilarityType = 'UsingActiFactorEuclidean', pls give UserSetting.actiFactor
userSetting.actiFactor = 1.0; % float, value range (0, 2]

% *** Pls select a way to give basic parameters,  
userSetting.baseParaType = 'UsingAvgBasePara'; % 'UsingIniBasePara', 'UsingOptBasePara', 'UsingAvgBasePara'
% ==> UsingAvgBasePara: the parameters are automaticaly assigned by average values; 
% ==> UsingIniBasePara: using '.idea-inipara' file and Pls provide '.idea-inipara'
% ==> UsingOptBasePara: using '.idea-optpara' file and Pls provide '.idea-optpara'
% ==> when UserSetting.baseParaType = 'UsingAvgBasePara', pls give UserSetting.anteUtilNum and UserSetting.conqUtilNum
userSetting.anteAttrUtilNum = 5; % integer, value range [2, inf]
userSetting.conqAttrUtilNum = 5; % integer, value range [2, inf]

% *** Pls select a way to achieve parameter learning. 
userSetting.paraLearningType = 'UsingNone'; % 'UsingNone', 'UsingDE', 'UsingGA', 'UsingPS', 'UsingFmincon'
% ==> UsingNone   : do not use parameter learning. 
% ==> UsingDE     : Differential Evoluation Algorithm. 
% ==> UsingGA     : Genetic Algorithm. 
% ==> UsingPS     : Pattern Search Algorithm. 
% ==> UsingFmincon: Fmincon in MATLAB
% ==> when UserSetting.paraLearningType ~= 'UsingNone', pls give UserSetting.parNum and UserSetting.genNum % Eq.(29) at Ref.[3]
userSetting.parNum = 20; % integer, value range [1, inf]
userSetting.genNum = 30; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_2013_EBRB(userSetting);
end

