function Main_Hou2024()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910
% Ref.[1] : Hou BB, et al., An extended belief rule-based system with hybrid sampling strategy for imbalanced rule base. Information Sciences, 2024, 684: 121288.
%% Pls define your settings in this section
% Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'};  
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-betadata' '.idea-wdata' for each dataset

% Pls give the number of assessment grades for antecedent attributes, 
userSetting.anteAttrUtilNum  = 5; % integer, value range [2, inf]

% Pls define the parameters related to determining the threshold for obtaining the overlapping rules
userSetting.threOfOverlap_U = 1;
userSetting.threOfOverlap_L = 0;
userSetting.stepOfOverlap   = 0.01;

% Pls define the parameters related to the determination of redundant negative rules
% userSetting.ratio   = 0.02;
userSetting.maxIter = 100;
userSetting.CR      = 0.9;

% Pls define the parameters related to AP algorithm
userSetting.threOfClu_L = 2;
userSetting.threOfClu_U = 10;

%% Pls do not modify the codes belows
IDEA_Hou2024(userSetting);
end

