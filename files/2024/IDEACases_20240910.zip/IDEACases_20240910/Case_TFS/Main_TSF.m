function Main_TSF()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Please determine the type of time series forecasting 
userSetting.TSFType = 'RGM'; % 'GM11', 'ARIMA', 'RGM'
% ==> If userSetting.TSFType = 'ARIMA', pls determine 
userSetting.paraP = 1; % integer, value range [1, inf]
userSetting.paraD = 1; % integer, value range [1, inf]
userSetting.paraQ = 1; % integer, value range [1, inf]

% *** Please determine the number of future times to predict 
userSetting.nxtTimeNum = 3; % integer, value range [1, inf]

%% Pls do not modify the codes belows
IDEA_TSF(userSetting);
end

