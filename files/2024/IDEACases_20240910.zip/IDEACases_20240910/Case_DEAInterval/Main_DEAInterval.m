function Main_DEAInterval()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Please provide '.idea-lowerxdata' '.idea-upperxdata' '.idea-lowerydata' '.idea-upperydata' for each dataset

% *** Pls select the type of interval DEA model
userSetting.intDEAType = 'IntBCC'; % 'IntCCR', 'IntBCC'
% ==> IntCCR: CCR model with interval data
% ==> IntBCC: BCC model with interval data

%% Pls do not modify the codes belows
IDEA_DEAInterval(userSetting);
end

