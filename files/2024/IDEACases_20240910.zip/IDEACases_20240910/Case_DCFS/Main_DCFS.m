function Main_DCFS()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1', 'case-2'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-tradata' '.idea-tstdata' '.idea-datainfo' for each dataset

% *** Please give the number of fuzzy labels for attributes 
userSetting.fuzzyLabelNum = 5; % integer, value range [2, inf]

% *** Please give the number of attributes in a window, 
userSetting.winAttrNum = 3; % integer, value range [2, inf]

%% Pls do not modify the codes belows
IDEA_DCFS(userSetting);
end

