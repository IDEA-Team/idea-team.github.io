function Main_Data2Beta()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'};
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-udata' for each dataset

% *** Pls select the type of transforming data into belief distribution
userSetting.transformType = 'UsingIntervalDataFunction'; % 'UsingAdjacentUFunction', 'UsingMinimaxUFunction', 'UsingIntervalDataFunction'
% ==> 'UsingMinimaxUFunction'    : Min/Max Utility-based Transformation
% ==> 'UsingAdjacentUFunction'   : Adjacent Utility-based Transformation
% ==> 'UsingIntervalDataFunction': Transform interval data into interval beta
% ==> If select 'UsingIntervalDataFunction', please provide '.idea-lowerdata', '.idea-upperdata', and '.idea-udata'.
% ==> If select 'UsingMinimaxUFunction' or 'UsingAdjacentUFunction', please provide '.idea-data' and '.idea-udata'.

% *** Pls select true, false
userSetting.betaReconstitution = false; % true, false
% ==> false: transform one data file into one beta file.
% ==> true : transform each data of all files into one beta file, i.e., 4 files and each has 3 data, the result is 3 beta files, where the 1st beta file consists of beta transformed 1st data of 4 data files. 

%% Pls do not modify the codes belows
IDEA_Data2Beta(userSetting);
end

