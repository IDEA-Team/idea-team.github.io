function Main_DEAInverse()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-1'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-xdata' '.idea-ydata' '.idea-zdata' for each dataset

% *** Pls select the type of inverse DEA model
userSetting.invDEAType = 'InvUDEA_JCLP2017'; % 'InvUDEA_JCLP2017', 'InvUDEA_SASC2021'
% ==> InvUDEA_JCLP2017: InvUDEA_JCLP2017 model
% ==> InvUDEA_SASC2021: InvUDEA_SASC2021 model
% ==> If userSetting.invDEAType = 'InvUDEA_JCLP2017', pls provide 'idea-deltaxwdata' 'idea-deltaydata' 'idea-deltazdata'
% ==> If userSetting.invDEAType = 'InvUDEA_SASC2021', pls provide 'idea-deltaallzdata'

%% Pls do not modify the codes belows
IDEA_DEAInverse(userSetting);
end

