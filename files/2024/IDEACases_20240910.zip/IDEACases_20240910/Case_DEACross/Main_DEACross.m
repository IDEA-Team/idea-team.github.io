function Main_DEACross()
% Homepage: https://idea-team.github.io
% Author  : Dr. Long-Hao Yang
% E-mail  : more026@hotmail.com
% Version : V20240910

%% Pls define your settings in this section
% *** Pls give the name of datasets, 
userSetting.dataSetNames = {'case-3', 'case-2', 'case-1'}; 
% ==> e.g.{'case-1'} for only one dataset, {'case-1', 'case-2'} for multiple datasets
% ==> Pls provide '.idea-xdata' '.idea-ydata' for each dataset

% *** Pls select the type of Cross DEA model
userSetting.crossDEAType = 'CrossCCR2010A'; % 'CrossCCR2010A', 'CrossCCR2010B', 'CrossCCR2010N', 'CrossCCR2018A', 'CrossCCR2018B'
% ==> CrossCCR2010A: CrossCCR2010 Aggressive model
% ==> CrossCCR2010B: CrossCCR2010 Benevolent model
% ==> CrossCCR2010N: CrossCCR2010 Neutral model
% ==> CrossCCR2018A: CrossCCR2018 Aggressive model
% ==> CrossCCR2018B: CrossCCR2018 Benevolent model
%% Pls do not modify the codes belows
IDEA_DEACross(userSetting);
end

